Name: Brian Mere

Notes: Color modes not equal to 1 or 2 per the 
canvas assignment will render as normal (ie: the straight pixel color value)